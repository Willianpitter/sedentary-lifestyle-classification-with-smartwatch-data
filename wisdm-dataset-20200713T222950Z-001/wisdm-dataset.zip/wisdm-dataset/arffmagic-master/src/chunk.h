#ifndef CHUNK_H
#define CHUNK_H
//what does it mean for records to become a chunk?
bool validRecord ();
bool belongsInChunk ();
void addRecord ();
void dumpChunk ();
#endif 