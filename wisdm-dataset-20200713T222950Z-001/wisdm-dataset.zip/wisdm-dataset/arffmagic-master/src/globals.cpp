#include "globals.h"

instancer chunk(WINDOW_SIZE * SAMPLING_RATE);
liner record(NUM_TOKENS);
std::vector<double> data[NUM_AXIS];