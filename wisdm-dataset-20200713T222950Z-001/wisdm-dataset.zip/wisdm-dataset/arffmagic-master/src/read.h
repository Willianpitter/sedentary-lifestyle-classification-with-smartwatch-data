#ifndef READ_H
#define READ_H
#include "arff.h"
//process of reading through the raw data file
void getRecord (arff&);
void rawdog (arff&);
#endif 